﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class BLLHotel
    {
        DAL.Hotel Mapper= new DAL.Hotel();
        public void ImprimiXml()
        {

            Mapper.ImprimirXML();

        }
    }
}
