﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace DAL
{
    public class Hotel
    {
        public void ImprimirXML()
        {
            string query = "Select * from Reservas";           
            DAL.Database db = new DAL.Database();
            DataTable dt = new DataTable();
            dt=db.CargarDataset(query);
           DataSet ds= new DataSet();
            ds.Tables.Add(dt);
           ds.WriteXml(@"C:\bd\Reservas.xml");
        }





    }
}
