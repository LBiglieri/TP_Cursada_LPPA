﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Xml;

namespace TP_Cursada
{
    /// <summary>
    /// Descripción breve de WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        [WebMethod]
        public string LeerXMl()
        {
            int TotalC = 0;
            string result = "";

            XmlDocument xmlDoc = new XmlDocument();
            string xmlPath = Server.MapPath("Reservas.xml"); // Ruta física del archivo XML

            try
            {
                xmlDoc.Load(xmlPath); // Carga el archivo XML desde la ruta especificada

                XmlNodeList xmlNodeList = xmlDoc.GetElementsByTagName("Id_Reserva");
                TotalC = xmlNodeList.Count;

                // Construye una cadena con la información que deseas mostrar
                result += "Información de reservas:\n";
                for (int i = 0; i < xmlNodeList.Count; i++)
                {
                    result += xmlNodeList[i].InnerText + ",\n";
                   
                }

                result += "\nTotal de reservas: " + TotalC;

                // Devuelve la cadena como respuesta al cliente
                return result;
            }
            catch (Exception ex)
            {
                // Manejo de errores y devolución de un mensaje de error al cliente
                return "Error al cargar el archivo XML: " + ex.Message;
            }
        }


    }
    }

